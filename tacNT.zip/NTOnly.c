#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#include "..\libtacacs.h"

int WSA_Start() {
    WORD        version_requested;      /* WinSock version number */
    WSADATA     winsock_data;           /* WinSock implementation data */
    int status;

    version_requested = MAKEWORD (1, 1);

    status = WSAStartup(version_requested, &winsock_data);

    if (status == 0)
        {
/*        fprintf (stderr, "Winsock version caller should use: %d\n"
                         "Highest version this DLL can support: %d\n"
                         "Winsock system desc: %s\n"
                         "Winsock system stat: %s\n"
                         "Max sockets per process: %d\n"
                         "Max UDP Datagram size: %d\n",
                         winsock_data.wVersion,
                         winsock_data.wHighVersion,
                         winsock_data.szDescription,
                         winsock_data.szSystemStatus,
                         winsock_data.iMaxSockets,
                         winsock_data.iMaxUdpDg);
*/
		return 1;
        }
    else {
	   tac_error("\r\n*** ERROR: WSAStartup failed with error %d\r\n", status);
		return 0;
	}
}

void WSA_End() {
	int status;

    status = WSACleanup ();

    if (status == SOCKET_ERROR)
	   tac_error("\r\n*** ERROR: Cannot WSACleanup with error %d\r\n", WSAGetLastError ());

}

void bzero(char *p, int len) {
	int i;
	for (i=0; i<len; i++) {
		p[i]=0;
	}
}

int inet_aton(const char *cp, struct in_addr *inp) {
    long addr;

    addr = inet_addr(cp);
    if (addr == ((long) -1)) return 0;

    memcpy(inp, &addr, sizeof(addr));
    return 1;
}
